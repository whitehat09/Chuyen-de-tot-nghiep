    
    <?php $__env->startSection('conten'); ?>


	

	<!doctype html>
	<html lang="en">
	  <head>
	    <!-- Required meta tags -->
	    <!-- Bootstrap CSS -->
           <link rel="stylesheet" type="text/css" href="source/css/chi-tiet.css">

	    <title>Hello, world!</title>
	  </head>
	  <body>
	  
		   <div class="top-dad" style="font-family: inherit">
				<header class="container top " style="">
					<div class="tieude">
						<h1>9 buoc nghe tieng anh dot pha	</h1>
					</div>
					
					<div class="gioithieu col-md-6 col-sm-8">
						Học Tiếng Anh không khó nó chỉ khó khi bạn không biết đột phá. Khoá học sẽ giúp nắm chắc các bước luyện nghe đỉnh cao, giúp khả năng nghe của bạn phát triển nhanh chóng.
					</div>

					<div class="anh-dai-dien col-12 ">
						
							<img src="https://static.unica.vn/uploads/thaoptt09@gmail.com/March222017202pm_hannah-pham_thumb.jpg"  class="img-circle"><a href=""><span></span>Hannah Phạm</span></a>
		                   
			        </div>

				</header>
			</div>	

			<div class="container noidung" style="padding:5px;">
				<div class="row" style="padding: 0;margin: 0">
					<div class="video-gioi-thieu col-md-8 col-12" style="padding: 0;margin: 0">
					<iframe  width="100%" height="400px" src="https://www.youtube.com/embed/ytcetH9Xp4U" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
				</div>

				<div class="tai-khoa-hoc col-md-4 col-12" style="padding: 0;margin: 0">
					<div class="container box box-im">
						<button type="button" class="btn btn-danger">TẢI XUỐNG</button>
						<button type="button" class="btn btn-giohang"> <i class="glyphicon glyphicon-shopping-cart"></i> Thêm vào giỏ hàng</button>
						<p><i class="far fa-clock"> </i> Thời lượng: <span>cacac</span></p>
						<p><i class="far fa-clock"> </i> Giáo trình: <span>cacac</span></p>
						<p><i class="far fa-clock"></i> Sở hữu khóa học trọn đời</span></p>

					</div>
					<div class="container box box-move">
						<button type="button" class="btn btn-danger">TẢI XUỐNG</button>
						<button type="button" class="btn btn-giohang"> <i class="glyphicon glyphicon-shopping-cart"></i> Thêm vào giỏ hàng</button>
						<p><i class="far fa-clock"> </i> Thời lượng: <span>cacac</span></p>
						<p><i class="far fa-clock"> </i> Giáo trình: <span>cacac</span></p>
						<p><i class="far fa-clock"></i> Sở hữu khóa học trọn đời</span></p>

					</div>
					
				</div>
						<div class="nut-duoi-video col-md-8">

                            <a class="btn btn-primary" href="#" role="button">Giới thiệu</a>
                            <a class="btn btn-primary" href="#" role="button">Nội dung khóa học</a>
                            <a class="btn btn-primary" href="#" role="button">Khóa học liên quan</a>
                            <a class="btn btn-primary" href="#" role="button">Thông tin giảng viên</a>
                            <a class="btn btn-primary" href="#" role="button">Đánh giá</a>
                             
                           
                        </div>
				</div>
				

				<div class="ban-se-hoc-duoc-gi col-md-8 col-12">
					<h3 style="margin: 20px 0;">Bạn sẽ học được gì</h3>
					<p>hoc dc rat nhieu thu</p>
				</div>

				<div class="gioi-thieu-khoa-hoc col-md-8 col-12">
					<h3 style="margin: 20px 0; border-bottom: 1px solid #d7d7d7">Giới thiệu khóa học</h3>
					<p>hoc dc rat nhieu thu</p>
				</div>

				<div class="gioi-thieu-khoa-hoc col-md-8 col-12">
					<h3 style="margin: 20px 0; border-bottom: 1px solid #d7d7d7">Thông tin giảng viên</h3>
					

				</div>


				
			</div>


				




	    <!-- Optional JavaScript -->
	    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
	   
	  </body>
	</html>

	 <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ChuyenDe-TN\ChuyenDe\resources\views/page/trang-chi-tiet.blade.php ENDPATH**/ ?>