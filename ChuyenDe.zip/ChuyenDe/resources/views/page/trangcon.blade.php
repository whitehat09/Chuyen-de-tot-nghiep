 @extends('master')
@section('conten')

			  <!--menu-->


<div class="container" style = "padding:15px 0">
  <div class="row content">
    <div class="col-sm-2 sidenav hidden-xs" style = "border:1px solid #d7d7d7; margin-top:30px">
      <h3 style = "border-bottom:1px solid #d7d7d7;padding-bottom:13px" align = "center">Danh Mục</h3>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="#section1">Ngoại ngữ</a></li>
        <li><a href="#section2">Tin học</a></li>
        <li><a href="#section3">Marketing</a></li>
        <li><a href="#section3">Thiết kế</a></li>
		<li><a href="#section3">Kinh doanh</a></li>
		<li><a href="#section3">Nghệ thuật</a></li>
		<li><a href="#section3">Nhiếp ảnh</a></li>
		<li><a href="#section3">Sức khỏe</a></li>
      </ul><br>
    </div>
    <br>
    <!--end menu-->
	
	<!--row 1-->
    <div class="col-sm-9" style = "width: 83%">
      <div>
        <h3>Khóa học nổi bật</p>
      </div>
      <div class="row">
        <div class="col-sm-3">
          <div class="well">
             <div style="border-radius: 10px;height: 269px;background-color: white;">
                        <img style="width: 100%;    border-radius: 10px 10px 0 0;height: 108.5px; " src="https://static.unica.vn/upload/images/2019/06/ky-nang-tim-viec-va-phong-van-thanh-cong_m_1561427707.jpg">
                        <div style="padding-left: 10px;" >
                             <h3 class="title-course" style="font-size:15px;font-weight: 600;overflow: hidden;margin-top: 8px;">
                                <span>
                                    Kỹ năng tìm việc và phỏng vấn thành ...
                                </span>
                            </h3>
                            <div style="font-size: 12px; color: #555;  min-height: 18px;">
                                <b>
                                    Nguyễn Phan Anh 
                                </b>
                            </div>
                            <div class="rate-course" style="display: inline-block;" itemscope="">
                                <span style="   color: #f26c4f;">
                                    <i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i>  3
                                </span>
                            </div>
                            <div style="margin: 0 7px;padding-top: 35px;">
                                                <span style="font-size: 15px; font-weight: bold; float: right;">
                                                    DOWNLOAD
                                                        
                                                </span>
                            </div>
                        </div>
                    </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well">
             <div style="border-radius: 10px;height: 269px;background-color: white;">
                        <img style="width: 100%;    border-radius: 10px 10px 0 0;height: 108.5px; " src="https://static.unica.vn/upload/images/2019/06/ky-nang-tim-viec-va-phong-van-thanh-cong_m_1561427707.jpg">
                        <div style="padding-left: 10px;" >
                             <h3 class="title-course" style="font-size:15px;font-weight: 600;overflow: hidden;margin-top: 8px;">
                                <span>
                                    Kỹ năng tìm việc và phỏng vấn thành ...
                                </span>
                            </h3>
                            <div style="font-size: 12px; color: #555;  min-height: 18px;">
                                <b>
                                    Nguyễn Phan Anh 
                                </b>
                            </div>
                            <div class="rate-course" style="display: inline-block;" itemscope="">
                                <span style="   color: #f26c4f;">
                                    <i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i>  3
                                </span>
                            </div>
                            <div style="margin: 0 7px;padding-top: 35px;">
                                                <span style="font-size: 15px; font-weight: bold; float: right;">
                                                    DOWNLOAD
                                                        
                                                </span>
                            </div>
                        </div>
                    </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well">
             <div style="border-radius: 10px;height: 269px;background-color: white;">
                        <img style="width: 100%;    border-radius: 10px 10px 0 0;height: 108.5px; " src="https://static.unica.vn/upload/images/2019/06/ky-nang-tim-viec-va-phong-van-thanh-cong_m_1561427707.jpg">
                        <div style="padding-left: 10px;" >
                             <h3 class="title-course" style="font-size:15px;font-weight: 600;overflow: hidden;margin-top: 8px;">
                                <span>
                                    Kỹ năng tìm việc và phỏng vấn thành ...
                                </span>
                            </h3>
                            <div style="font-size: 12px; color: #555;  min-height: 18px;">
                                <b>
                                    Nguyễn Phan Anh 
                                </b>
                            </div>
                            <div class="rate-course" style="display: inline-block;" itemscope="">
                                <span style="   color: #f26c4f;">
                                    <i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i>  3
                                </span>
                            </div>
                            <div style="margin: 0 7px;padding-top: 35px;">
                                                <span style="font-size: 15px; font-weight: bold; float: right;">
                                                    DOWNLOAD
                                                        
                                                </span>
                            </div>
                        </div>
                    </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well">
             <div style="border-radius: 10px;height: 269px;background-color: white;">
                        <img style="width: 100%;    border-radius: 10px 10px 0 0;height: 108.5px; " src="https://static.unica.vn/upload/images/2019/06/ky-nang-tim-viec-va-phong-van-thanh-cong_m_1561427707.jpg">
                        <div style="padding-left: 10px;" >
                             <h3 class="title-course" style="font-size:15px;font-weight: 600;overflow: hidden;margin-top: 8px;">
                                <span>
                                    Kỹ năng tìm việc và phỏng vấn thành ...
                                </span>
                            </h3>
                            <div style="font-size: 12px; color: #555;  min-height: 18px;">
                                <b>
                                    Nguyễn Phan Anh 
                                </b>
                            </div>
                            <div class="rate-course" style="display: inline-block;" itemscope="">
                                <span style="   color: #f26c4f;">
                                    <i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i>  3
                                </span>
                            </div>
                            <div style="margin: 0 7px;padding-top: 35px;">
                                                <span style="font-size: 15px; font-weight: bold; float: right;">
                                                    DOWNLOAD
                                                        
                                                </span>
                            </div>
                        </div>
                    </div>
          </div>
        </div>
      </div>
	  <!--end row1-->
	  
	  <!--row2-->
      <div>
        <h4>Khóa học ngoại ngữ</h4>
        <h3>Tất cả [120 khóa học]</h3>
        
      </div>
      <div class="row">
        <div class="col-sm-3">
          <div class="well">
             <div class="lol" style="border-radius: 10px;height: 269px;background-color: white;">
                        <img style="width: 100%;    border-radius: 10px 10px 0 0;height: 108.5px; " src="https://static.unica.vn/upload/images/2019/06/ky-nang-tim-viec-va-phong-van-thanh-cong_m_1561427707.jpg">
                        <div style="padding-left: 10px;" >
                             <h3 class="title-course" style="font-size:15px;font-weight: 600;overflow: hidden;margin-top: 8px;">
                                <span>
                                    Kỹ năng tìm việc và phỏng vấn thành ...
                                </span>
                            </h3>
                            <div style="font-size: 12px; color: #555;  min-height: 18px;">
                                <b>
                                    Nguyễn Phan Anh 
                                </b>
                            </div>
                            <div class="rate-course" style="display: inline-block;" itemscope="">
                                <span style="   color: #f26c4f;">
                                    <i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i>  3
                                </span>
                            </div>
                            <div style="margin: 0 7px;padding-top: 35px;">
                                                <span style="font-size: 15px; font-weight: bold; float: right;">
                                                    DOWNLOAD
                                                        
                                                </span>
                            </div>
                        </div>
                    </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well">
             <div style="border-radius: 10px;height: 269px;background-color: white;">
                        <img style="width: 100%;    border-radius: 10px 10px 0 0;height: 108.5px; " src="https://static.unica.vn/upload/images/2019/06/ky-nang-tim-viec-va-phong-van-thanh-cong_m_1561427707.jpg">
                        <div style="padding-left: 10px;" >
                             <h3 class="title-course" style="font-size:15px;font-weight: 600;overflow: hidden;margin-top: 8px;">
                                <span>
                                    Kỹ năng tìm việc và phỏng vấn thành ...
                                </span>
                            </h3>
                            <div style="font-size: 12px; color: #555;  min-height: 18px;">
                                <b>
                                    Nguyễn Phan Anh 
                                </b>
                            </div>
                            <div class="rate-course" style="display: inline-block;" itemscope="">
                                <span style="   color: #f26c4f;">
                                    <i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i>  3
                                </span>
                            </div>
                            <div style="margin: 0 7px;padding-top: 35px;">
                                                <span style="font-size: 15px; font-weight: bold; float: right;">
                                                    DOWNLOAD
                                                        
                                                </span>
                            </div>
                        </div>
                    </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well">
             <div style="border-radius: 10px;height: 269px;background-color: white;">
                        <img style="width: 100%;    border-radius: 10px 10px 0 0;height: 108.5px; " src="https://static.unica.vn/upload/images/2019/06/ky-nang-tim-viec-va-phong-van-thanh-cong_m_1561427707.jpg">
                        <div style="padding-left: 10px;" >
                             <h3 class="title-course" style="font-size:15px;font-weight: 600;overflow: hidden;margin-top: 8px;">
                                <span>
                                    Kỹ năng tìm việc và phỏng vấn thành ...
                                </span>
                            </h3>
                            <div style="font-size: 12px; color: #555;  min-height: 18px;">
                                <b>
                                    Nguyễn Phan Anh 
                                </b>
                            </div>
                            <div class="rate-course" style="display: inline-block;" itemscope="">
                                <span style="   color: #f26c4f;">
                                    <i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i>  3
                                </span>
                            </div>
                            <div style="margin: 0 7px;padding-top: 35px;">
                                                <span style="font-size: 15px; font-weight: bold; float: right;">
                                                    DOWNLOAD
                                                        
                                                </span>
                            </div>
                        </div>
                    </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well">
             <div style="border-radius: 10px;height: 269px;background-color: white;">
                        <img style="width: 100%;    border-radius: 10px 10px 0 0;height: 108.5px; " src="https://static.unica.vn/upload/images/2019/06/ky-nang-tim-viec-va-phong-van-thanh-cong_m_1561427707.jpg">
                        <div style="padding-left: 10px;" >
                             <h3 class="title-course" style="font-size:15px;font-weight: 600;overflow: hidden;margin-top: 8px;">
                                <span>
                                    Kỹ năng tìm việc và phỏng vấn thành ...
                                </span>
                            </h3>
                            <div style="font-size: 12px; color: #555;  min-height: 18px;">
                                <b>
                                    Nguyễn Phan Anh 
                                </b>
                            </div>
                            <div class="rate-course" style="display: inline-block;" itemscope="">
                                <span style="   color: #f26c4f;">
                                    <i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i>  3
                                </span>
                            </div>
                            <div style="margin: 0 7px;padding-top: 35px;">
                                                <span style="font-size: 15px; font-weight: bold; float: right;">
                                                    DOWNLOAD
                                                        
                                                </span>
                            </div>
                        </div>
                    </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-sm-3">
          <div class="well">
             <div style="border-radius: 10px;height: 269px;background-color: white;">
                        <img style="width: 100%;    border-radius: 10px 10px 0 0;height: 108.5px; " src="https://static.unica.vn/upload/images/2019/06/ky-nang-tim-viec-va-phong-van-thanh-cong_m_1561427707.jpg">
                        <div style="padding-left: 10px;" >
                             <h3 class="title-course" style="font-size:15px;font-weight: 600;overflow: hidden;margin-top: 8px;">
                                <span>
                                    Kỹ năng tìm việc và phỏng vấn thành ...
                                </span>
                            </h3>
                            <div style="font-size: 12px; color: #555;  min-height: 18px;">
                                <b>
                                    Nguyễn Phan Anh 
                                </b>
                            </div>
                            <div class="rate-course" style="display: inline-block;" itemscope="">
                                <span style="   color: #f26c4f;">
                                    <i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i>  3
                                </span>
                            </div>
                            <div style="margin: 0 7px;padding-top: 35px;">
                                                <span style="font-size: 15px; font-weight: bold; float: right;">
                                                    DOWNLOAD
                                                        
                                                </span>
                            </div>
                        </div>
                    </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well">
             <div style="border-radius: 10px;height: 269px;background-color: white;">
                        <img style="width: 100%;    border-radius: 10px 10px 0 0;height: 108.5px; " src="https://static.unica.vn/upload/images/2019/06/ky-nang-tim-viec-va-phong-van-thanh-cong_m_1561427707.jpg">
                        <div style="padding-left: 10px;" >
                             <h3 class="title-course" style="font-size:15px;font-weight: 600;overflow: hidden;margin-top: 8px;">
                                <span>
                                    Kỹ năng tìm việc và phỏng vấn thành ...
                                </span>
                            </h3>
                            <div style="font-size: 12px; color: #555;  min-height: 18px;">
                                <b>
                                    Nguyễn Phan Anh 
                                </b>
                            </div>
                            <div class="rate-course" style="display: inline-block;" itemscope="">
                                <span style="   color: #f26c4f;">
                                    <i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i>  3
                                </span>
                            </div>
                            <div style="margin: 0 7px;padding-top: 35px;">
                                                <span style="font-size: 15px; font-weight: bold; float: right;">
                                                    DOWNLOAD
                                                        
                                                </span>
                            </div>
                        </div>
                    </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well">
             <div style="border-radius: 10px;height: 269px;background-color: white;">
                        <img style="width: 100%;    border-radius: 10px 10px 0 0;height: 108.5px; " src="https://static.unica.vn/upload/images/2019/06/ky-nang-tim-viec-va-phong-van-thanh-cong_m_1561427707.jpg">
                        <div style="padding-left: 10px;" >
                             <h3 class="title-course" style="font-size:15px;font-weight: 600;overflow: hidden;margin-top: 8px;">
                                <span>
                                    Kỹ năng tìm việc và phỏng vấn thành ...
                                </span>
                            </h3>
                            <div style="font-size: 12px; color: #555;  min-height: 18px;">
                                <b>
                                    Nguyễn Phan Anh 
                                </b>
                            </div>
                            <div class="rate-course" style="display: inline-block;" itemscope="">
                                <span style="   color: #f26c4f;">
                                    <i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i>  3
                                </span>
                            </div>
                            <div style="margin: 0 7px;padding-top: 35px;">
                                                <span style="font-size: 15px; font-weight: bold; float: right;">
                                                    DOWNLOAD
                                                        
                                                </span>
                            </div>
                        </div>
                    </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well">
             <div style="border-radius: 10px;height: 269px;background-color: white;">
                        <img style="width: 100%;    border-radius: 10px 10px 0 0;height: 108.5px; " src="https://static.unica.vn/upload/images/2019/06/ky-nang-tim-viec-va-phong-van-thanh-cong_m_1561427707.jpg">
                        <div style="padding-left: 10px;" >
                             <h3 class="title-course" style="font-size:15px;font-weight: 600;overflow: hidden;margin-top: 8px;">
                                <span>
                                    Kỹ năng tìm việc và phỏng vấn thành ...
                                </span>
                            </h3>
                            <div style="font-size: 12px; color: #555;  min-height: 18px;">
                                <b>
                                    Nguyễn Phan Anh 
                                </b>
                            </div>
                            <div class="rate-course" style="display: inline-block;" itemscope="">
                                <span style="   color: #f26c4f;">
                                    <i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i>  3
                                </span>
                            </div>
                            <div style="margin: 0 7px;padding-top: 35px;">
                                                <span style="font-size: 15px; font-weight: bold; float: right;">
                                                    DOWNLOAD
                                                        
                                                </span>
                            </div>
                        </div>
                    </div>
          </div>
        </div>
      </div>
      
      <div class="row">
        <div class="col-sm-3">
          <div class="well">
             <div style="border-radius: 10px;height: 269px;background-color: white;">
                        <img style="width: 100%;    border-radius: 10px 10px 0 0;height: 108.5px; " src="https://static.unica.vn/upload/images/2019/06/ky-nang-tim-viec-va-phong-van-thanh-cong_m_1561427707.jpg">
                        <div style="padding-left: 10px;" >
                             <h3 class="title-course" style="font-size:15px;font-weight: 600;overflow: hidden;margin-top: 8px;">
                                <span>
                                    Kỹ năng tìm việc và phỏng vấn thành ...
                                </span>
                            </h3>
                            <div style="font-size: 12px; color: #555;  min-height: 18px;">
                                <b>
                                    Nguyễn Phan Anh 
                                </b>
                            </div>
                            <div class="rate-course" style="display: inline-block;" itemscope="">
                                <span style="   color: #f26c4f;">
                                    <i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i>  3
                                </span>
                            </div>
                            <div style="margin: 0 7px;padding-top: 35px;">
                                                <span style="font-size: 15px; font-weight: bold; float: right;">
                                                    DOWNLOAD
                                                        
                                                </span>
                            </div>
                        </div>
                    </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well">
             <div style="border-radius: 10px;height: 269px;background-color: white;">
                        <img style="width: 100%;    border-radius: 10px 10px 0 0;height: 108.5px; " src="https://static.unica.vn/upload/images/2019/06/ky-nang-tim-viec-va-phong-van-thanh-cong_m_1561427707.jpg">
                        <div style="padding-left: 10px;" >
                             <h3 class="title-course" style="font-size:15px;font-weight: 600;overflow: hidden;margin-top: 8px;">
                                <span>
                                    Kỹ năng tìm việc và phỏng vấn thành ...
                                </span>
                            </h3>
                            <div style="font-size: 12px; color: #555;  min-height: 18px;">
                                <b>
                                    Nguyễn Phan Anh 
                                </b>
                            </div>
                            <div class="rate-course" style="display: inline-block;" itemscope="">
                                <span style="   color: #f26c4f;">
                                    <i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i>  3
                                </span>
                            </div>
                            <div style="margin: 0 7px;padding-top: 35px;">
                                                <span style="font-size: 15px; font-weight: bold; float: right;">
                                                    DOWNLOAD
                                                        
                                                </span>
                            </div>
                        </div>
                    </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well">
             <div style="border-radius: 10px;height: 269px;background-color: white;">
                        <img style="width: 100%;    border-radius: 10px 10px 0 0;height: 108.5px; " src="https://static.unica.vn/upload/images/2019/06/ky-nang-tim-viec-va-phong-van-thanh-cong_m_1561427707.jpg">
                        <div style="padding-left: 10px;" >
                             <h3 class="title-course" style="font-size:15px;font-weight: 600;overflow: hidden;margin-top: 8px;">
                                <span>
                                    Kỹ năng tìm việc và phỏng vấn thành ...
                                </span>
                            </h3>
                            <div style="font-size: 12px; color: #555;  min-height: 18px;">
                                <b>
                                    Nguyễn Phan Anh 
                                </b>
                            </div>
                            <div class="rate-course" style="display: inline-block;" itemscope="">
                                <span style="   color: #f26c4f;">
                                    <i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i>  3
                                </span>
                            </div>
                            <div style="margin: 0 7px;padding-top: 35px;">
                                                <span style="font-size: 15px; font-weight: bold; float: right;">
                                                    DOWNLOAD
                                                        
                                                </span>
                            </div>
                        </div>
                    </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well">
             <div style="border-radius: 10px;height: 269px;background-color: white;">
                        <img style="width: 100%;    border-radius: 10px 10px 0 0;height: 108.5px; " src="https://static.unica.vn/upload/images/2019/06/ky-nang-tim-viec-va-phong-van-thanh-cong_m_1561427707.jpg">
                        <div style="padding-left: 10px;" >
                             <h3 class="title-course" style="font-size:15px;font-weight: 600;overflow: hidden;margin-top: 8px;">
                                <span>
                                    Kỹ năng tìm việc và phỏng vấn thành ...
                                </span>
                            </h3>
                            <div style="font-size: 12px; color: #555;  min-height: 18px;">
                                <b>
                                    Nguyễn Phan Anh 
                                </b>
                            </div>
                            <div class="rate-course" style="display: inline-block;" itemscope="">
                                <span style="   color: #f26c4f;">
                                    <i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i><i class="fa fa-star-o co-or" aria-hidden="true"></i>  3
                                </span>
                            </div>
                            <div style="margin: 0 7px;padding-top: 35px;">
                                                <span style="font-size: 15px; font-weight: bold; float: right;">
                                                    DOWNLOAD
                                                        
                                                </span>
                                                
                            </div>
                        </div>
                    </div>
          </div>
        </div>
      </div>
      
      
      
	  <!--end row2-->
      </div>
    </div>
  </div>
</div>
<nav aria-label="Page navigation example" align ="center">
  <ul class="pagination">
    <li class="page-item"><a class="page-link" href="#"><<</a></li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item"><a class="page-link" href="#">>></a></li>
  </ul>
</nav>





  @endsection