<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class khoahoc extends Model
{
    protected $table = "baihoc";
    protected $table = "giaovien";

    public function loaikh(){
    	return $this->belongsTo('App\loaiKH','maLoaiKH','maKH');
    }

      public function giaovien()
    {
    	return $this->hasMany('App\khoahoc','idGV','maKH');
    }
}
