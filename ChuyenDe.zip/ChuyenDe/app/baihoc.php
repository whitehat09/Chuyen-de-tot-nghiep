<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class baihoc extends Model
{
      public function khoahoc()
    {
    	return $this->hasMany('App\khoahoc','maKH','id');
    }
}
