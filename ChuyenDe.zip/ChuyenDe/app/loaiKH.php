<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class loaiKH extends Model
{
    //
    protected $table = "khoahoc";

    public function khoahoc()
    {
    	return $this->hasMany('App\khoahoc','maLoaiKH','idKH');
    }
}
